const LEAGUE_ID = '91035049';
const SEASON = 2026;
const ALLOWED = new Set(['mTeam','mRoster','mStandings','mMatchupScore','mSettings','mDraftDetail','mStatus','mSchedule','mScoreboard','mBoxscore','mLiveScoring','mTransactions2']);

export default async function handler(req, res) {
  try {
    const season = Math.max(2019, Math.min(2030, Number(req.query.season || SEASON)));
    const views = String(req.query.views || 'mTeam,mStandings,mStatus,mSettings').split(',').map(s=>s.trim()).filter(v=>ALLOWED.has(v));
    const params = new URLSearchParams();
    (views.length ? views : ['mTeam']).forEach(v=>params.append('view',v));
    if (req.query.week) {
      params.set('matchupPeriodId', String(req.query.week));
      params.set('scoringPeriodId', String(req.query.week));
    }
    const url = `https://lm-api-reads.fantasy.espn.com/apis/v3/games/ffl/seasons/${season}/segments/0/leagues/${LEAGUE_ID}?${params}`;
    const headers = { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' };
    if (views.includes('mTransactions2')) {
      headers['x-fantasy-filter'] = JSON.stringify({transactions:{filterType:{value:['FREEAGENT','WAIVER','TRADE']}}});
    }
    const r = await fetch(url,{headers});
    const text = await r.text();
    res.setHeader('Cache-Control','s-maxage=30, stale-while-revalidate=120');
    res.status(r.status).setHeader('Content-Type','application/json').send(text);
  } catch (e) {
    res.status(500).json({error:'ESPN request failed', detail:String(e?.message||e)});
  }
}
